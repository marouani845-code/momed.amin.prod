(() => {
  const grid = document.getElementById("productGrid");
  const filterButtons = [...document.querySelectorAll(".filter")];
  const menuToggle = document.getElementById("menuToggle");
  const nav = document.getElementById("nav");
  let currentFilter = "All";

  document.getElementById("year").textContent = new Date().getFullYear();

  function renderProducts() {
    const products = (window.PRODUCTIONS || []).filter(p =>
      currentFilter === "All" || p.genre === currentFilter
    );
    if (!products.length) {
      grid.innerHTML = '<p class="empty-state">No productions in this category yet.</p>';
      return;
    }
    grid.innerHTML = products.map(p => {
      const ready = p.checkoutUrl &&
        p.checkoutUrl.startsWith("https://") &&
        !p.checkoutUrl.includes("PASTE_YOUR_CHECKOUT_URL_HERE");
      const preview = p.preview
        ? `<audio controls preload="none" aria-label="Preview ${escapeHtml(p.title)}"><source src="${escapeAttr(p.preview)}" type="audio/mpeg">Your browser does not support audio.</audio>`
        : '<p class="meta">Preview coming soon</p>';
      return `
        <article class="product-card">
          <div class="cover ${escapeAttr(p.cover)}"><span class="cover-symbol">${escapeHtml(p.symbol)}</span></div>
          <div class="product-info">
            <span class="pill">${escapeHtml(p.genre.toUpperCase())}</span>
            <h3>${escapeHtml(p.title)}</h3>
            <p class="meta">${escapeHtml(p.details)}</p>
            ${preview}
            <div class="product-bottom">
              <span class="price">${escapeHtml(p.price)}</span>
              ${ready
                ? `<a class="button primary buy-button" href="${escapeAttr(p.checkoutUrl)}" target="_blank" rel="noopener noreferrer">Buy securely ↗</a>`
                : `<button class="button primary buy-button" type="button" disabled title="Add a hosted checkout URL in products.js">Checkout setup needed</button>`}
            </div>
          </div>
        </article>`;
    }).join("");
  }

  // Escape product text before inserting it into the page.
  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, ch => ({
      "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
    }[ch]));
  }
  function escapeAttr(value) { return escapeHtml(value); }

  filterButtons.forEach(button => button.addEventListener("click", () => {
    currentFilter = button.dataset.filter;
    filterButtons.forEach(b => b.classList.toggle("active", b === button));
    renderProducts();
  }));

  menuToggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(open));
  });
  nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
    nav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
  }));

  renderProducts();
})();
