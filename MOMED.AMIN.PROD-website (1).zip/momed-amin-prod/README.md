# MOMED.AMIN.PROD music store

## Files
- `index.html`: website
- `style.css`: responsive design
- `script.js`: product rendering, category filters and mobile menu
- `products.js`: product information and hosted checkout links
- `success.html` / `cancel.html`: simple checkout return pages
- `audio/`: put your own short MP3 previews here

## Run locally
Open `index.html` in a browser, or run a simple local server.

## Publish on GitHub Pages
1. Create a GitHub repository.
2. Upload all files and the `audio` folder.
3. Go to **Settings → Pages**.
4. Select **Deploy from a branch**, branch `main`, folder `/(root)`, and save.

## Set up real payments
This project deliberately uses hosted checkout links. It does not collect card numbers and does not store payment secrets.

1. Check whether a digital-product checkout provider accepts your country, identity, bank payout method, and music products. Provider approval is not guaranteed.
2. Create each beat as a digital product in the provider's dashboard. Set the correct price, license terms, and digital-file delivery.
3. Copy the provider's real hosted checkout URL for each product.
4. Open `products.js` and replace each `PASTE_YOUR_CHECKOUT_URL_HERE` with that product's actual HTTPS checkout URL.
5. Replace `YOUR_EMAIL@example.com` in `index.html` and the return pages with the producer's real support email.
6. Test a purchase in the provider's test mode if available, and confirm that receipt and download delivery work before sharing the website.

The buy buttons remain disabled until real HTTPS checkout URLs are added. This prevents the site from pretending a payment is configured.

## Audio
Add original or properly licensed previews:
- `audio/beat-01.mp3`
- `audio/beat-02.mp3`
- `audio/beat-03.mp3`

Use only audio you have rights to sell or preview. Decide and publish clear license terms (for example, permitted uses, limits, exclusivity, refunds, and delivery) before accepting orders.

## Important
GitHub Pages is static hosting. The success page is not proof of payment. Use the checkout provider's order records and receipts to confirm sales. Do not add secret API keys to files committed to a public repository.
