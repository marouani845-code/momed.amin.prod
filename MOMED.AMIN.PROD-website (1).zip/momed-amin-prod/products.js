/*
  EDIT YOUR PRODUCTS HERE.
  For each product, paste the real hosted checkout URL from your payment provider.
  Do not put secret API keys in this file.
*/
window.PRODUCTIONS = [
  {
    id: "midnight-dreams",
    title: "Midnight Dreams",
    genre: "Trap",
    details: "Melodic • Atmospheric • 140 BPM",
    price: "€25",
    symbol: "✦",
    cover: "trap",
    preview: "audio/beat-01.mp3",
    checkoutUrl: "PASTE_YOUR_CHECKOUT_URL_HERE"
  },
  {
    id: "blue-horizon",
    title: "Blue Horizon",
    genre: "R&B",
    details: "Chill • Smooth • 95 BPM",
    price: "€20",
    symbol: "〰",
    cover: "rnb",
    preview: "audio/beat-02.mp3",
    checkoutUrl: "PASTE_YOUR_CHECKOUT_URL_HERE"
  },
  {
    id: "after-hours",
    title: "After Hours",
    genre: "Drill",
    details: "Dark • Hard • 150 BPM",
    price: "€30",
    symbol: "♫",
    cover: "drill",
    preview: "audio/beat-03.mp3",
    checkoutUrl: "PASTE_YOUR_CHECKOUT_URL_HERE"
  }
];
